create function update_any_timestamp() returns trigger
    language plpgsql
as
$$
BEGIN
    CASE TG_TABLE_NAME
        WHEN 'scrobble' THEN NEW.first_listened_at := CURRENT_TIMESTAMP;
        WHEN 'release_rating' THEN NEW.rated_at := CURRENT_TIMESTAMP;
        WHEN 'track_rating' THEN NEW.rated_at := CURRENT_TIMESTAMP;
    END CASE;
    RETURN NEW;
END;
$$;

alter function update_any_timestamp() owner to postgres;

